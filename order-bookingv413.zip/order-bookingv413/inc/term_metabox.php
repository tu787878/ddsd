<?php 
function dsmart_taxonomy_add_custom_meta_field() {
	wp_nonce_field( 'taxonomy-term-usecoupon-form-save', 'taxonomy-term-usecoupon-save-form-nonce' ); ?>
	<div class="form-field">
		<label for="can_not_use_coupon"><?php _e( 'Can not use coupon?' ); ?></label>
		<input type="checkbox" name="can_not_use_coupon" id="can_not_use_coupon" value="">
		<p class="description"><?php _e( 'Tick if you dont\'t want to use coupon for this category.' ); ?></p>
	</div>
	<div class="form-field">
		<label for="pools"><?php _e( 'Pool Druckverteilung auswählen' ); ?></label>
		<select class="widefat" name="pool" id="pools" >
					<option value=""><?php _e("None") ?></option>
					<?php 
						$pools = get_terms( array(
							'taxonomy' => 'pool',
							'hide_empty' => false,
						) );

						foreach($pools as $pool){
							?>
								<option value="<?php echo $pool->term_id ?>"><?php echo $pool->name ?></option>
							<?php
						}
					?>
				</select>
	</div>
	<div class="form-field">
		<label for="category_pos"><?php _e( 'Enter your category position' ); ?></label>
		<input type="number" name="category_pos" id="category_pos" value="0">
	</div>
	<div class="form-field">
		<label><?php _e( 'Open only time' ); ?></label>
		<div class="list-tax-date">
			<div class="item-date">
				<select class="widefat" name="time_date[]" required>
					<option value="mo"><?php _e("Montag") ?></option>
					<option value="tu"><?php _e("Dienstag") ?></option>
					<option value="we"><?php _e("Mittwoch") ?></option>
					<option value="th"><?php _e("Donnerstag") ?></option>
					<option value="fr"><?php _e("Freitag") ?></option>
					<option value="sa"><?php _e("Samstag") ?></option>
					<option value="su"><?php _e("Sonntag"); ?></option>
				</select>
				<input type="text" name="time_open[]" class="widefat timepicker" placeholder="<?php _e('Open time') ?>" value="" autocomplete="off" style="margin-bottom: 5px;"/>
				<input type="text" name="time_close[]" class="widefat timepicker" placeholder="<?php _e('Close time') ?>" value="" autocomplete="off"/>
				<span class="remove-date">x</span>
			</div>
		</div>
		<button class="button add-new-date" type="button"><?php _e("Neue Zeile hinzufugen"); ?></button>
	</div>
<?php }
add_action( 'product-cat_add_form_fields', 'dsmart_taxonomy_add_custom_meta_field', 10, 2 );

function dsmart_taxonomy_edit_custom_meta_field($term) {
    $t_id = $term->term_id;
   	$can_not_use_coupon = get_term_meta( $t_id, 'can_not_use_coupon', true );
   	$p = get_term_meta( $t_id, 'pool', true );
   	// $p = 7;
   	$tax_time = get_term_meta( $t_id, 'tax_time', true );
   	$category_pos = (intval(get_term_meta( $t_id, 'category_pos', true )) > 0) ? intval(get_term_meta( $t_id, 'category_pos', true )) : 0;
    wp_nonce_field( 'taxonomy-term-usecoupon-form-save', 'taxonomy-term-usecoupon-save-form-nonce' );?>
	<tr class="form-field">
		<th scope="row" valign="top"><label for="can_not_use_coupon"><?php _e( 'Can not use coupon?' ); ?></label></th>
		<td>
			<input type="checkbox" name="can_not_use_coupon" id="can_not_use_coupon" value="1" <?php echo ( $can_not_use_coupon == "1") ? 'checked' : ''; ?>/>
			<p class="description"><?php _e( 'Tick if you dont\'t want to use coupon for this category.' ); ?></p>
		</td>
	</tr>

	<tr class="form-field">
		<th scope="row" valign="top"><label for="pools"><?php _e( 'Pool Druckverteilung auswählen' ); ?></label></th>
		<td>
		<select class="widefat" name="pool" id="pools" >
					<option value=""><?php _e("None") ?></option>
					<?php 
						$pools = get_terms( array(
							'taxonomy' => 'pool',
							'hide_empty' => false,
						) );

						foreach($pools as $pool){
							
							?>
								<option value="<?php echo $pool->term_id ?>" <?php if($p == $pool->term_id) echo 'selected' ?>><?php echo $pool->name ?></option>
							<?php
						}
					?>
				</select>
		</td>
	</tr>
	<tr class="form-field">
		<th scope="row" valign="top"><label for="category_pos"><?php _e( 'Enter your category position' ); ?></label></th>
		<td>
			<input type="number" name="category_pos" id="category_pos" value="<?php echo $category_pos; ?>" />
		</td>
	</tr>
	<tr class="form-field">
		<th scope="row" valign="top"><label><?php _e( 'Open only time' ); ?></label></th>
		<td>
			<div class="list-tax-date">
				<?php if($tax_time != "" && is_array($tax_time) && count($tax_time) > 0): 
					foreach($tax_time as $key => $item): ?>
						<div class="item-date">
							<select class="widefat" name="time_date[]" required>
								<option value="mo" <?php if($item['date'] == "mo"){echo 'selected';} ?>><?php _e("Montag") ?></option>
								<option value="tu" <?php if($item['date'] == "tu"){echo 'selected';} ?>><?php _e("Dienstag") ?></option>
								<option value="we" <?php if($item['date'] == "we"){echo 'selected';} ?>><?php _e("Mittwoch") ?></option>
								<option value="th" <?php if($item['date'] == "th"){echo 'selected';} ?>><?php _e("Donnerstag") ?></option>
								<option value="fr" <?php if($item['date'] == "fr"){echo 'selected';} ?>><?php _e("Freitag") ?></option>
								<option value="sa" <?php if($item['date'] == "sa"){echo 'selected';} ?>><?php _e("Samstag") ?></option>
								<option value="su" <?php if($item['date'] == "su"){echo 'selected';} ?>><?php _e("Sonntag"); ?></option>
							</select>
							<input type="text" name="time_open[]" class="widefat timepicker" placeholder="<?php _e('Open time') ?>" value="<?php echo $item['open']; ?>" autocomplete="off" style="margin-bottom: 5px;"/>
							<input type="text" name="time_close[]" class="widefat timepicker" placeholder="<?php _e('Close time') ?>" value="<?php echo $item['close']; ?>" autocomplete="off"/>
							<span class="remove-date">x</span>
						</div>
					<?php endforeach;
				endif; ?>
			</div>
			<button class="button add-new-date" type="button"><?php _e("Neue Zeile hinzufugen"); ?></button>
		</td>
	</tr>
<?php }

add_action( 'product-cat_edit_form_fields', 'dsmart_taxonomy_edit_custom_meta_field', 10, 2 );

function dsmart_save_taxonomy_custom_meta_field( $term_id ) {
		if (
			isset( $_POST['taxonomy-term-usecoupon-save-form-nonce'] ) &&
			wp_verify_nonce( $_POST['taxonomy-term-usecoupon-save-form-nonce'], 'taxonomy-term-usecoupon-form-save' ) &&
			isset( $_POST['taxonomy'] )
		){
			$new_can_not_use_coupon = (isset($_POST['can_not_use_coupon']) && $_POST['can_not_use_coupon'] == "1") ? "1" : "0";
			update_term_meta( $term_id, 'can_not_use_coupon', $new_can_not_use_coupon );
			$pool = (intval($_POST['pool']) > 0) ? intval($_POST['pool']) : '' ;
			update_term_meta( $term_id, 'pool', $pool );
			$category_pos = (intval($_POST['category_pos']) > 0) ? intval($_POST['category_pos']) : 0 ;
			update_term_meta( $term_id, 'category_pos', $category_pos );
			$time_date = $_POST['time_date'];
			$time_open = $_POST['time_open'];
			$time_close = $_POST['time_close'];
			$array = array();
			if(is_array($time_date) && count($time_date) > 0){
				foreach ($time_date as $key => $value) {
					$array[] = array('date' => $value,'open' => $time_open[$key],'close' => $time_close[$key]);
				}
			}else{
				$array = "";
			}
			update_term_meta( $term_id, 'tax_time', $array );
		}
}  
add_action( 'edited_product-cat', 'dsmart_save_taxonomy_custom_meta_field', 10, 2 );  
add_action( 'create_product-cat', 'dsmart_save_taxonomy_custom_meta_field', 10, 2 );